# app.py
import streamlit as st
import pandas as pd
import pickle
import numpy as np

# Configuración de la página
st.set_page_config(page_title="Predicción Precio Autos", page_icon="🚗", layout="wide")

# Función para cargar los artefactos
@st.cache_resource
def load_artifacts():
    try:
        with open('models/best_model.pkl', 'rb') as f:
            model = pickle.load(f)
        with open('models/scaler.pkl', 'rb') as f:
            scaler = pickle.load(f)
        with open('models/label_encoders.pkl', 'rb') as f:
            le_dict = pickle.load(f)
        with open('models/feature_names.pkl', 'rb') as f:
            feature_names = pickle.load(f)
        with open('models/brand_counts.pkl', 'rb') as f:
            brand_counts = pickle.load(f)
        return model, scaler, le_dict, feature_names, brand_counts
    except FileNotFoundError:
        st.error("⚠️ No se encontraron los archivos del modelo. Por favor ejecuta primero 'train_model.py'.")
        return None, None, None, None, None

model, scaler, le_dict, feature_names, brand_counts = load_artifacts()

def main():
    st.title("🚗 Predicción de Precios de Autos Usados")
    st.markdown("Introduce las características del vehículo para obtener una estimación de precio.")

    if model is None:
        return

    # --- Sidebar para Inputs ---
    st.sidebar.header("Características del Auto")

    # Función auxiliar para obtener opciones de los encoders
    def get_options(col_name):
        return list(le_dict[col_name].classes_)

    # Inputs del usuario
    brand = st.sidebar.selectbox("Marca", get_options('brand'))
    
    # Filtrar modelos podría ser complejo sin el dataset original completo cargado,
    # así que mostramos todos los modelos disponibles en el encoder.
    car_model = st.sidebar.selectbox("Modelo", get_options('model'))
    
    model_year = st.sidebar.number_input("Año del Modelo", min_value=1970, max_value=2024, value=2018)
    milage = st.sidebar.number_input("Millaje (Millas)", min_value=0, value=50000)
    
    horsepower = st.sidebar.number_input("Caballos de Fuerza (HP)", min_value=50, max_value=1000, value=200)
    
    col1, col2 = st.sidebar.columns(2)
    with col1:
        fuel_type = st.selectbox("Tipo de Combustible", get_options('fuel_type'))
        transmission = st.selectbox("Transmisión", get_options('transmission'))
        accident = st.selectbox("Accidentes Reportados", get_options('accident'))
    
    with col2:
        ext_col = st.selectbox("Color Exterior", get_options('ext_col'))
        int_col = st.selectbox("Color Interior", get_options('int_col'))
        clean_title = st.selectbox("Título Limpio", get_options('clean_title'))

    # --- Procesamiento de Inputs ---
    if st.sidebar.button("Predecir Precio"):
        # 1. Calcular Feature Engineering
        car_age = 2024 - model_year
        
        # Frecuencia de la marca (usar 0 o media si es nueva, aunque el selectbox limita esto)
        brand_freq = brand_counts.get(brand, 0)

        # 2. Crear DataFrame con los datos crudos (para debug o visualización si quisieras)
        # 3. Codificar variables
        input_data = {
            'brand': le_dict['brand'].transform([brand])[0],
            'model': le_dict['model'].transform([car_model])[0],
            'model_year': model_year,
            'milage': milage,
            'fuel_type': le_dict['fuel_type'].transform([fuel_type])[0],
            'transmission': le_dict['transmission'].transform([transmission])[0],
            'ext_col': le_dict['ext_col'].transform([ext_col])[0],
            'int_col': le_dict['int_col'].transform([int_col])[0],
            'accident': le_dict['accident'].transform([accident])[0],
            'clean_title': le_dict['clean_title'].transform([clean_title])[0],
            'car_age': car_age,
            'brand_frequency': brand_freq,
            'horsepower': horsepower
        }
        
        # Asegurar el orden correcto de las columnas
        df_input = pd.DataFrame([input_data])
        df_input = df_input[feature_names] # Reordenar según el entrenamiento

        # 4. Escalar
        try:
            df_input_scaled = scaler.transform(df_input)
            
            # 5. Predicción
            prediction = model.predict(df_input_scaled)
            price = prediction[0]

            # Mostrar resultado
            st.divider()
            st.subheader(f"💰 Precio Estimado: ${price:,.2f}")
            
            # Mostrar detalles
            with st.expander("Ver detalles de los datos procesados"):
                st.write("Datos de entrada (codificados y escalados):")
                st.dataframe(df_input)
                
        except Exception as e:
            st.error(f"Ocurrió un error en la predicción: {e}")

    # Información adicional
    st.markdown("---")
    st.markdown("*Modelo entrenado con Ridge Regression optimizado.*")

if __name__ == "__main__":
    main()