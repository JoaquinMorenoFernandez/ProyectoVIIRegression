# train_model.py
import pandas as pd
import numpy as np
import pickle
import os
import re
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import Ridge

# 1. Cargar datos
print("Cargando dataset...")
# Asegúrate de tener 'used_cars.csv' en la misma carpeta
df = pd.read_csv('used_cars.csv')

# 2. Limpieza (Funciones originales del notebook)
def clean_price(price):
    if pd.isna(price): return np.nan
    return float(str(price).replace('$', '').replace(',', ''))

def clean_mileage(mileage):
    if pd.isna(mileage): return np.nan
    return float(str(mileage).replace(' mi.', '').replace(',', ''))

def extract_hp(engine_str):
    if pd.isna(engine_str): return 0.0
    match = re.search(r'(\d+\.?\d*)HP', str(engine_str))
    if match: return float(match.group(1))
    return 0.0

print("Limpiando datos...")
df['price'] = df['price'].apply(clean_price)
df['milage'] = df['milage'].apply(clean_mileage)

# Copia para limpieza
df_clean = df.copy()
df_clean['model_year'] = pd.to_numeric(df_clean['model_year'], errors='coerce').astype('Int64')
df_clean = df_clean[df_clean['price'].notna()].reset_index(drop=True)

# Eliminar nulos críticos (según el notebook)
df_clean = df_clean.dropna(subset=['fuel_type', 'accident', 'clean_title'])

# 3. Feature Engineering
print("Generando características...")
df_clean['car_age'] = 2024 - df_clean['model_year']

# Guardar frecuencia de marcas (CRÍTICO para la app)
brand_counts = df_clean['brand'].value_counts().to_dict()
df_clean['brand_frequency'] = df_clean['brand'].map(brand_counts)

df_clean['horsepower'] = df_clean['engine'].apply(extract_hp)

# 4. Label Encoding
print("Codificando variables categóricas...")
df_encoded = df_clean.copy()
df_encoded = df_encoded.drop(['engine'], axis=1) # Eliminar engine original

categorical_cols = ['brand', 'model', 'fuel_type', 'transmission', 
                    'ext_col', 'int_col', 'accident', 'clean_title']
le_dict = {}

for col in categorical_cols:
    le = LabelEncoder()
    # Convertimos a string para asegurar consistencia
    df_encoded[col] = le.fit_transform(df_encoded[col].astype(str))
    le_dict[col] = le

# 5. Preparar X e y
X = df_encoded.drop(['price'], axis=1)
y = df_encoded['price']

# Dividir train/test (para mantener consistencia con el escalado)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 6. Escalado
print("Escalando datos...")
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
# Ajustamos scaler solo con train, como en el notebook

# 7. Entrenar el mejor modelo (Ridge con el alpha óptimo encontrado por Optuna)
print("Entrenando modelo Ridge...")
best_alpha = 0.001006 # Valor tomado de los resultados de tu notebook
model = Ridge(alpha=best_alpha, random_state=42)
model.fit(X_train_scaled, y_train)

# 8. Guardar todo
print("Guardando modelos en la carpeta 'models/'...")
os.makedirs('models', exist_ok=True)

with open('models/best_model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('models/scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

with open('models/label_encoders.pkl', 'wb') as f:
    pickle.dump(le_dict, f)

with open('models/feature_names.pkl', 'wb') as f:
    pickle.dump(X.columns.tolist(), f)
    
with open('models/brand_counts.pkl', 'wb') as f: # Extra necesario para la app
    pickle.dump(brand_counts, f)

print("¡Listo! Ejecuta ahora 'streamlit run app.py'")